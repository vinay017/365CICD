﻿using Microsoft.Xrm.Sdk;
using System;

namespace Plugins
{
    [CrmPluginRegistration(MessageNameEnum.Create, "account", StageEnum.PostOperation, ExecutionModeEnum.Synchronous, null, "Account Creation Follow Up Phone Call", 1, IsolationModeEnum.Sandbox)]
    public class AccountPostCreatePlugin : IPlugin
    {

        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the execution context from the service provider.
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            // Obtain the organization service reference.
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {
                var target = context.InputParameters["Target"] as Entity;

                Entity phonecall = new Entity("phonecall");
                phonecall["regardingobjectid"] = target.ToEntityReference();
                phonecall["phonenumber"] = target["telephone1"];
                phonecall["scheduledend"] = DateTime.Now.AddDays(5);
                phonecall["subject"] = "Introductory phonecall";

                service.Create(phonecall);
            }
        }
    }
}
