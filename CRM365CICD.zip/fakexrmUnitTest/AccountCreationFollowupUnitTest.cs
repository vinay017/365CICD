﻿using System;
using FakeItEasy;
using FakeXrmEasy;
using TestPlugin;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Plugins;

namespace fakexrmUnitTest
{
    [TestClass]
   public class AccountCreationFollowupUnitTest
    {
        [TestMethod]
        public void FollowupPhoneCallTest()
        {
            var fakedContext = new XrmFakedContext();
            //  fakedContext.ProxyTypesAssembly = Assembly.GetExecutingAssembly(); //Needed to be able to return early bound entities
            #region Plugin Inputs
            var guid1 = Guid.NewGuid();
            var target = new Entity("account") { Id = guid1 };
            target["telephone1"] = "1234";

            ParameterCollection inputParameters = new ParameterCollection();
            inputParameters.Add("Target", target);

            ParameterCollection outputParameters = new ParameterCollection();
            outputParameters.Add("id", guid1);

            #endregion

            #region execute Plugin

            //fakedContext.ExecutePluginWith<AccountPostCreatePlugin>
            fakedContext.ExecutePluginWith< AccountPostCreatePlugin>(inputParameters, outputParameters, null, null);
            #endregion
            //The plugin creates a followup activity, check that that one exists
            var tasks = fakedContext.CreateQuery("phonecall").ToList<Entity>(); 

            Assert.AreEqual(true,tasks.Count == 1);
          //  Assert.AreEqual(true,tasks[0].Subject.Equals("Send e-mail to the new customer."));
          //  Assert.AreEqual(true,tasks[0].RegardingObjectId != null && tasks[0].RegardingObjectId.Id.Equals(guid1));
        }
    }
}
